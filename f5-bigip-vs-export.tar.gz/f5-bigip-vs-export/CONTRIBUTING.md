# Contributing

## How to Contribute

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/gtm-export`
3. Commit your changes: `git commit -m "Add GTM WideIP export layer"`
4. Push to branch: `git push origin feature/gtm-export`
5. Open a Pull Request

## Coding Guidelines

- Keep the script self-contained — no external dependencies beyond standard Linux tools
- Test on at least BIG-IP 14.x before submitting
- Document any `cut` field positions with a comment showing the expected tmsh output format
- Preserve backward compatibility with the existing CSV column order

## Roadmap / Open Items

| Feature | Notes |
|---|---|
| GTM/DNS WideIP export | `tmsh list gtm wideip a recursive` — pool type must be specified |
| ASM/WAF policy per VS | `policies { }` block in VS config |
| iRule-to-VS mapping | `rules { }` block already in VS one-line output |
| iControl REST version | No tmsh required — portable to any host with curl |
| Bulk tmsh mode | Replace per-VS loop with 4 bulk pulls for large environments |

## Reporting Issues

Include the following when opening an issue:
- BIG-IP version (`tmsh show sys version`)
- Sample tmsh output that breaks the script:
  ```bash
  tmsh list ltm pool <poolname> | grep address | cat -A
  ```
- Error output with `bash -x f5_vs_export.sh 2>&1 | head -50`
