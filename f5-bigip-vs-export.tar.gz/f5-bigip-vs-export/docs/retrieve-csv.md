# Retrieving the CSV from BIG-IP

SCP is often blocked on F5 because the `admin` account defaults to `tmsh` shell, not bash. Use one of the methods below.

---

## Method 1 — cat + Copy-Paste (Quickest)

```bash
cat /var/tmp/f5_vs_*.csv
```
Select all terminal output → paste into Notepad → File → Save As → `f5_export.csv`

Best for files under ~3000 lines.

---

## Method 2 — REST API Download (Recommended)

Works from any workstation with curl. No shell change needed.

**Step 1 — Stage the file on BIG-IP:**
```bash
cp /var/tmp/f5_vs_*.csv /var/config/rest/downloads/
```

**Step 2 — Download from workstation:**
```bash
# Linux / Mac
curl -sku admin:PASSWORD \
  "https://<BIGIP-IP>/mgmt/shared/file-transfer/downloads/f5_vs_<TIMESTAMP>.csv" \
  -o f5_export.csv

# Windows PowerShell
Invoke-WebRequest `
  -Uri "https://<BIGIP-IP>/mgmt/shared/file-transfer/downloads/f5_vs_<TIMESTAMP>.csv" `
  -Credential (Get-Credential) `
  -OutFile f5_export.csv `
  -SkipCertificateCheck
```

---

## Method 3 — Push FROM F5 to Workstation

Your workstation needs SSH/SCP server running (OpenSSH on Windows, standard on Mac/Linux).

```bash
# Run this ON the BIG-IP:
scp /var/tmp/f5_vs_*.csv youruser@<WORKSTATION-IP>:/home/youruser/Desktop/
```

---

## Method 4 — Fix SCP (One-Time)

If admin shell is tmsh, temporarily switch it to bash for the transfer:
```bash
# On BIG-IP:
chsh -s /bin/bash admin

# Now SCP works from workstation:
scp root@<BIGIP-IP>:/var/tmp/f5_vs_*.csv ./

# Switch back:
chsh -s /bin/tmsh admin
```

---

## Method 5 — BIG-IP Web GUI

**System → File Management → iFile List** does not expose `/var/tmp` directly.
Use the REST API method (Method 2) instead — it's the same underlying mechanism the GUI uses.
