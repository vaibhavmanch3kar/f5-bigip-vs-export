# Troubleshooting Guide

## Member IPs Show Blank

**Symptom:** `Member_IPs` column is empty in CSV.

**Cause:** The `cut -d" " -f14` command requires exactly 12 leading spaces before the `address` keyword in `tmsh list ltm pool` output. This is standard on BIG-IP 14.x/15.x/16.x. Older versions may use 8 spaces.

**Diagnose:**
```bash
tmsh list ltm pool <poolname> | grep address | cat -A
```
Count the spaces before `address`. If it's 8 spaces, change `-f14` to `-f10` in the script:
```bash
# Line 103 in f5_vs_export.sh
# Change from:
MEMBER_IPS=$(echo "$POOL_CFG" | grep address | cut -d" " -f14 ...)
# To (for 8-space indent / BIG-IP 13.x):
MEMBER_IPS=$(echo "$POOL_CFG" | grep address | cut -d" " -f10 ...)
```

**Alternative fix (version-independent):**
```bash
MEMBER_IPS=$(echo "$POOL_CFG" | awk '/address/{print $2}' | tr '\n' ' ')
```
`awk` collapses any whitespace as one delimiter — always returns field 2 regardless of indentation.

---

## Pool Shows `(pool not found)`

**Symptom:** Pool column has data but Member_IPs shows `(pool not found)`.

**Cause:** The pool path extracted from the VS config doesn't match the pool path from `tmsh list ltm pool recursive`. Usually a partition prefix difference.

**Diagnose:**
```bash
# What the VS config reports:
tmsh list ltm virtual <vs-name> | grep "^    pool"

# What pool recursive lists:
tmsh list ltm pool recursive | grep "^ltm pool"

# Compare the paths
```

---

## WinSCP Disconnects Mid-Run

**Symptom:** Dialog: *"Host is not communicating for more than 15 seconds"*

**Fix 1 — Use tmux (best):**
```bash
tmux new -s f5export
./f5_vs_export.sh
# If disconnected: tmux attach -t f5export
```

**Fix 2 — Run in background:**
```bash
nohup ./f5_vs_export.sh > /var/tmp/f5_run.log 2>&1 &
tail -f /var/tmp/f5_run.log
```

**Fix 3 — WinSCP keepalive:**
Session → Properties → Connection → Send keepalive null packets every 10 seconds.

---

## Script Exits Immediately with `tmsh: command not found`

You are running in bash but your PATH doesn't include tmsh. Fix:
```bash
export PATH=$PATH:/usr/bin
# or run as root
sudo bash f5_vs_export.sh
```

---

## `grep -oP` Not Available

Some BIG-IP versions ship with a grep that doesn't support Perl regex (`-P`). The port extraction line uses `-oP`. If this fails:
```bash
# Replace the PORTS= block with:
PORTS=$(echo "$POOL_CFG" \
    | grep -oE '/[^ ]+:[0-9]+( \{)' \
    | grep -oE ':[0-9]+' \
    | tr -d ':' \
    | tr '\n' ' ')
```

---

## Debug Mode

Run with `bash -x` to trace every command:
```bash
bash -x /var/tmp/f5_vs_export.sh 2>&1 | head -100
```
This will show exactly which tmsh commands are running and what they return.
