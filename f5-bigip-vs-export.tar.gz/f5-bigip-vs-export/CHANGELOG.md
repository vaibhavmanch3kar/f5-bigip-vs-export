# Changelog

All notable changes to this project are documented here.

---

## [2.0] — 2026-04-27

### Added
- Real-time screen output — formatted table printed per VS as it processes
- `Admin_State` column (enabled/disabled)
- `Availability` column (available/offline/unknown)
- `Reason` column (human-readable status from tmsh show)
- `LB_Method` column (round-robin, least-connections, etc.)
- `Monitor` column (pool health monitor name)
- `Members_Up` — count of pool members with availability = available
- `Members_Down` — count of pool members offline or unavailable
- `Members_Enabled` — admin-enabled member count
- `Members_Disabled` — admin-disabled member count
- `Member_IPs` — resolved IP:Port per member (not just node name)
- Port pairing alongside IPs using member name `:port` extraction
- CSV fields wrapped in double quotes — handles commas in Reason strings
- `Partition` column extracted from VS full path
- Timestamped output filename `/var/tmp/f5_vs_YYYYMMDD_HHMMSS.csv`
- REST API download instructions in summary output
- tmux / nohup run guidance for large environments

### Changed
- Pool line grep changed from `grep pool` to `grep "^    pool "` to avoid
  false match on `snat pool` lines in VS config
- Member IP extraction confirmed working with `cut -d" " -f14` on BIG-IP
  14.x/15.x where tmsh uses 12 leading spaces before `address` keyword

### Fixed
- Empty member IPs caused by `snat pool` line contaminating pool variable

---

## [1.0] — Original

### Base
- F5 KB K72255145 script — VS name, destination, pool name, member addresses
- Single loop over all partitions using `tmsh -q -c "cd /; list /ltm virtual recursive"`
- Member IPs via `tmsh list ltm pool | grep address | cut -d" " -f14`
